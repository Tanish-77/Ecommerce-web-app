export { default as useGetMappedCategories } from "./useGetMappedCategories";
