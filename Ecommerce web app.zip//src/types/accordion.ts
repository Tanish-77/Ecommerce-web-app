import { SxProps, Theme } from "@mui/material";

export interface IAccordionProps {
  accordionStyles: SxProps<Theme>;
}
