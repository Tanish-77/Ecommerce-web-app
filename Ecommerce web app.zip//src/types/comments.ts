export interface IComment {
  id: number;
  owner: string;
  avatarUrl: string;
  ratingPoint: number;
  comment: string;
}
