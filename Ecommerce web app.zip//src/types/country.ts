export interface ICountry {
  code: string;
  label: string;
  phone: string;
  suggested?: boolean;
}
