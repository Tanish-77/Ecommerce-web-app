export interface ICurrentUser {
  uid: string;
  displayName: string;
  email: string;
}
