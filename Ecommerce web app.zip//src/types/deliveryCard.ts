export interface ICardData {
  id: string;
  price: string;
  description: string;
  iconName: string;
}
